package com.capgemini.lesson4.operators;

public class PrefixPostfix {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int numA = 5;
		    int numB = 10;
		    int numC = 0;

		    numC = --numA + numB--;
		    System.out.println(numA);
		    System.out.println(numC);
		  
	}

}
